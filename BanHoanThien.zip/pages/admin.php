<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>

<body>
    <h1>Admin</h1>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Username</th>
                <th>Password</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $u) : ?>

                <tr>
                    <td>
                        <?php echo $u['id']; ?>
                    </td>
                    <td>
                        <?php echo $u['username']; ?>
                    </td>
                    <td>
                        <?php echo $u['password']; ?>
                    </td>
                    <td>
                        <?php echo $u['role']; ?>
                    </td>
                    <td class="actions">
                        <a href="/update?id=<?php echo $u['id']; ?>" class="edit-button">Edit</a>
                        <a href="/delete?id=<?php echo $u['id']; ?>" class="delete-button">Delete</a>
                    </td>
                </tr>
            <?php endforeach ?>
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</body>

</html>