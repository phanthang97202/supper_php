<?php
include_once(__DIR__ . '/services/AdminService.php');
// $_SESSION['auth'] = [
//     "username" => 'admin',
//     "role" => 1
// ];
$path = strtok($_SERVER['REQUEST_URI'], "?"); // cắt dần chuỗi

$service = new AdminService();

$isAdmin = $service->isPermission();

if (empty($_SESSION['auth'])) {
    include_once(__DIR__ . '/pages/login.php');
}
if ($isAdmin) {
    switch ($path) {
        case '/index.html':
            include_once(__DIR__ . '/pages/home.php');
        case '/admin':
            return $service->getUsers();
        case '/update':
            return $service->updateUser();
        case '/delete':
            return $service->deleteUser();
    }
} else {
    switch ($path) {
        case '/index.html':
            include_once(__DIR__ . '/pages/home.php');
            break;
    }
}
