<?php
class BaseService
{
    public function renderView($page, $data = null)
    {
        ob_start();
        require_once(__DIR__ . "/../pages/$page");
        $content = ob_get_clean();
        ob_clean();
        echo $content;
    }

    public function isPermission()
    {
        if (!empty($_SESSION['auth']) && $_SESSION['auth']['role'] == 1) {
            return true;
        } else {
            return false;
        }
    }
}
