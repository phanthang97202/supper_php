<?php
require_once(__DIR__ . '/BaseService.php');
class AdminService extends BaseService
{
    public function getUsers()
    {
        $connection = new PDO("mysql:host=localhost;dbname=ontotnghiep2", "root", "");
        $data = $connection->query("select * from users")->fetchAll(PDO::FETCH_ASSOC);
        return $this->renderView('admin.php', $data);
    }
    public function deleteUser()
    {
        try {
            $id = (int)$_GET['id'];
            $connection = new PDO("mysql:host=localhost;dbname=ontotnghiep2", "root", "");
            $sql = "delete from users where id = :id";
            $sth = $connection->prepare($sql);
            $sth->bindParam(':id', $id, PDO::PARAM_INT);
            $sth->execute();
            header('Location: /admin');
            return true;
        } catch (\Throwable $th) {
            var_dump('delete failed');
            return false;
        }
    }
    public function updateUser()
    {
        try {
            $data = [];
            $id = $_GET['id'];
            $connection = new PDO("mysql:host=localhost;dbname=ontotnghiep2", "root", "");
            $data = $connection->query("select id, username, password, role from users where id = $id")->fetchAll(PDO::FETCH_ASSOC);

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $request = (object)$_POST;
                $sql = "update users set username = ?, password = ?, role = ? where id = ?";
                $connection->prepare($sql)->execute([
                    $request->username,
                    $request->password,
                    $request->role,
                    $id
                ]);
                header("Location: /admin");
            }
        } catch (\Throwable $th) {
            echo 'Failed to update';
        }

        return $this->renderView('update.php', $data[0]);
    }
}
